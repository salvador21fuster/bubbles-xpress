from fastapi import APIRouter, Body, Query, Path

router = APIRouter()

@router.post("/auth/login")
def login(body: dict = Body(...)):
    return {"token": "demo-token", "user": {"email": body.get("email")}}

@router.post("/orders")
def create_order(body: dict = Body(...)):
    return {"id": "ord_demo", **body}

@router.post("/orders/{id}/confirm")
def confirm(id: str = Path(...)):
    return {"id": id, "status": "CONFIRMED"}

@router.post("/orders/{id}/bags")
def create_bags(id: str = Path(...), body: dict = Body(...)):
    return {"order_id": id, "bags": body.get("bags", [])}

@router.post("/scan")
def scan(body: dict = Body(...)):
    return {"accepted": True, "event": body}

@router.post("/orders/{id}/subcontract")
def subcontract(id: str = Path(...), body: dict = Body(...)):
    return {"order_id": id, "subcontract": body}

@router.post("/splits/calculate")
def calc_split(order_id: str = Query(...)):
    return {"order_id": order_id, "split": {"origin": 0.2, "processing": 0.55, "driver": 0.1, "platform": 0.15}}

@router.post("/orders/{id}/invoice")
def invoice(id: str = Path(...)):
    return {"id": id, "invoice_pdf_url": "https://example.com/invoice.pdf"}

@router.get("/audit")
def audit():
    return {"results": []}
