from fastapi import FastAPI, Body, Query, Path
from app.routers import routes

app = FastAPI(title="Mr Bubbles Express API (FastAPI)")
app.include_router(routes.router, prefix="/api")

@app.get("/health")
def health():
    return {"ok": True, "service": "mrbubbles-api-fastapi"}
