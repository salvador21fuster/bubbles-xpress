import { Controller, Get, Post, Body, Query, Param } from '@nestjs/common';

@Controller()
export class AppController {
  @Get('health')
  health() { return { ok: true, service: 'mrbubbles-api' }; }

  @Post('auth/login')
  login(@Body() body: any) { return { token: 'demo-token', user: { email: body.email } }; }

  @Post('orders')
  createOrder(@Body() body: any) { return { id: 'ord_demo', ...body }; }

  @Post('orders/:id/confirm')
  confirm(@Param('id') id: string) { return { id, status: 'CONFIRMED' }; }

  @Post('orders/:id/bags')
  createBags(@Param('id') id: string, @Body() body: any) { return { order_id: id, bags: body.bags || [] }; }

  @Post('scan')
  scan(@Body() body: any) { return { accepted: true, event: body }; }

  @Post('orders/:id/subcontract')
  subcontract(@Param('id') id: string, @Body() body: any) { return { order_id: id, subcontract: body }; }

  @Post('splits/calculate')
  calcSplit(@Query('order_id') order_id: string) { return { order_id, split: { origin: 0.2, processing: 0.55, driver: 0.1, platform: 0.15 } }; }

  @Post('orders/:id/invoice')
  invoice(@Param('id') id: string) { return { id, invoice_pdf_url: 'https://example.com/invoice.pdf' }; }

  @Get('audit')
  audit() { return { results: [] }; }
}
