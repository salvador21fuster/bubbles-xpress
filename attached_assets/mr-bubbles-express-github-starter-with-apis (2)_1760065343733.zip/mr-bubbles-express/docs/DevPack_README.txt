Mr Bubbles Express – Developer Pack (v3)
======================================

This pack contains all core materials for building and testing the Mr Bubbles Express laundry platform.

CONTENTS
--------
1. Mr_Bubbles_Express_OnePage_Brief.pdf
   → One-page engineering summary describing product surfaces, workflows, data model, QR/label system,
     revenue splits, anti-fraud rules, and MVP acceptance criteria.

2. Mr_Bubbles_Express_Postman_Collection.json
   → Postman v2.1 collection containing all core API endpoints:
     Auth, Orders, Scans, Bags, Subcontracts, Revenue Splits, Invoices, Admin Policy, and Audit queries.
     Import into Postman → set {{baseUrl}} to API host → authenticate → test.

3. Mr_Bubbles_Express_Architecture.png
   → Simple architecture diagram showing front-end (Customer/Driver/Admin apps) connected to
     the backend/API layer.

USAGE
-----
- Use the OnePage_Brief.pdf as a high-level engineering guide when coding the backend and mobile apps.
- Use the Postman collection for API testing and integration verification.
- Use the architecture diagram for quick visual context or presentations.

CREDITS
-------
System concept & spec: Ben O'Brien
Primary developer: Ronan
Architecture & documentation: Zoe (AI assistant)

Version: v3 – October 2025
