# Mr Bubbles Express

Uber-style laundry network with Customer & Driver apps, Shop/Admin portals, QR item tracking, policy-driven revenue splits,
label printing, anti-fraud, payouts, and VAT invoices.

## Structure
- `api/` — Backend (Node/Nest or FastAPI) + PostgreSQL schemas and services
- `mobile/` — React Native apps (Customer & Driver)
- `portal/` — Web portals (Shop, Admin) using Next.js
- `infra/` — Docker, k8s, IaC
- `docs/` — Specs, diagrams, Postman, one-pagers

## Quickstart (dev)
1. Copy `.env.example` -> `.env` and fill values.
2. `docker compose up -d` (API + Postgres + Redis)
3. Import Postman collection in `docs/postman/` and hit `{{baseUrl}}`.
