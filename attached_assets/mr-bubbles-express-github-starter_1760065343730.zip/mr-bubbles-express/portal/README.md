# Portal (Next.js)
- Shop Portal: intake/QC/pack, subcontract inbox
- Admin Portal: policies, payouts, audit
