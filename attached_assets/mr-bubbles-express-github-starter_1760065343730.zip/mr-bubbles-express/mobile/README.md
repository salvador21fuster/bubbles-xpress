# Mobile (React Native / Expo)
- Customer and Driver apps
- BLE label printing
- Offline SQLite + outbox
