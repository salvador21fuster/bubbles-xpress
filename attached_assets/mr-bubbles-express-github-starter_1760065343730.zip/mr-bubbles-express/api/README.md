# API
Backend service for Orders, Scans, Bags, Subcontracts, Splits, Invoices, Admin/Audit.

## Choose a stack
- **Option A:** Node.js + NestJS
- **Option B:** Python + FastAPI

Implement the same endpoints either way. Use PostgreSQL + Redis, emit events to Streams/Kafka (outbox pattern).
