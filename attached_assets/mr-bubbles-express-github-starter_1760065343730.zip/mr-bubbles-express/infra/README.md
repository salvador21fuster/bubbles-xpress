# Infra
- `k8s/` – Kubernetes manifests
- `terraform/` – Cloud infra (S3, DB, etc.)
- `otel/` – OpenTelemetry, Grafana/Loki/Tempo
